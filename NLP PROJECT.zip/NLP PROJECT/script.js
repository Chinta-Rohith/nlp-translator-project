let dictionary = {};

// Load JSON data
fetch("data.json")
    .then(response => response.json())
    .then(data => {
        dictionary = data;
        console.log("✅ Dictionary Loaded");
    })
    .catch(error => {
        console.error("❌ Error loading JSON:", error);
    });

// Translate function
function translateText() {
    let input = document.getElementById("inputText").value.trim().toLowerCase();
    let output = document.getElementById("output");

    // If empty input
    if (!input) {
        output.innerHTML = "";
        return;
    }

    // Split into words (handles punctuation)
    let words = input.split(/[\s,.!?]+/);

    let translatedWords = [];

    // Translate word by word
    words.forEach(word => {
        if (dictionary[word]) {
            translatedWords.push(dictionary[word]);
        }
    });

    // Show ONLY translated result
    if (translatedWords.length > 0) {
        output.innerHTML = translatedWords.join(" ");
    } else {
        output.innerHTML = "❌ No matching word found";
    }
}