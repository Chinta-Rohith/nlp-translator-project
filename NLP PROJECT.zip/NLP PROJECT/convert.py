import pandas as pd
import json

# Load CSV (UTF-8 BOM supported)
df = pd.read_csv("english_to_urdu_utf8_bom.csv")

# Get column names automatically
eng_col = df.columns[0]
urd_col = df.columns[1]

word_dict = {}

for eng, urd in zip(df[eng_col], df[urd_col]):
    eng_words = str(eng).lower().split()
    urd_words = str(urd).split()

    # Map word-by-word
    for i in range(min(len(eng_words), len(urd_words))):
        word_dict[eng_words[i]] = urd_words[i]

# Save JSON
with open("data.json", "w", encoding="utf-8") as f:
    json.dump(word_dict, f, ensure_ascii=False, indent=4)

print("✅ data.json created successfully!")